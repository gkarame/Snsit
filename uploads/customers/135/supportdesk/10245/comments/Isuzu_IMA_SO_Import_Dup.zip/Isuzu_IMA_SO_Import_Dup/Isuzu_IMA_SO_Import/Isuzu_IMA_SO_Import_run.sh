cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: isuzu.isuzu_ima_so_import_0_1.Isuzu_IMA_SO_Import --context=Development $* 
-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	09/08/10
-- Purpose:	Purge records in LotxLocxID, Lot and SKUxLoc tables if it's qty = 0
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------
-- Note:
-- Usr can run this script with two parameters ( Var1, Var2 ) or without parameter (default Var1 = 30, Var2 =30)
--    Var1 : How old record (in days) should be purged
--           (e.g. purge inventory records with qty = 0 if it is old than 60 days old)
--    Var2 : How old record (in days) should be updated to 0 for pendingmovein qty
--           (e.g. updated pendingmovein qty to 0 if it is old than 60 days old)
-- Run steps: 	1) Login sqlplus against warehouse db and run SPInventoryPurge.sql script to create a PROCEDURE
--		2) run EXEC SPInventoryPurge() or EXEC SPInventoryPurge(60,60)
--		3) run 'select * from alert where modulename = 'PurgeInventoryTables' order by alertkey' to check log that is created in alert table
-------------------------------------------------------------------
CREATE PROCEDURE SPInventoryPurge(@purge_days int = 30,
                                          @p_pendingmoveindays int = 30) AS
Declare @v_count int
Declare @local_n_err int

Set @v_count = 0

Begin Transaction

INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
	VALUES(CONVERT(char(17),getdate(),121) + '1','PurgeInventoryTables','Start purge process')

SET @local_n_err = @@ERROR 

IF @local_n_err <> 0 
BEGIN
	Rollback Transaction
END
ELSE
BEGIN
	commit Transaction
END 

--Delete zero records from SKUxLOC table 
Begin Transaction
Set @local_n_err = 0
 
SELECT @v_count = count(1)	
	FROM SKUxLOC
		WHERE LocationType NOT IN ('PICK', 'CASE')
		AND QTY = 0
		AND QTYALLOCATED = 0
		AND QTYPICKED = 0
		AND QTYEXPECTED = 0
		AND QTYPICKINPROCESS = 0
		AND EditDate < (getdate()-@purge_days)

IF @v_count > 0
BEGIN
	DELETE FROM SKUxLOC
		WHERE LocationType NOT IN ('PICK', 'CASE')
		AND QTY = 0
		AND QTYALLOCATED = 0
		AND QTYPICKED = 0
		AND QTYEXPECTED = 0
		AND QTYPICKINPROCESS = 0
		AND EditDate < (getdate()-@purge_days) 

	SET @local_n_err = @@ERROR 
END




IF @local_n_err <> 0
BEGIN
	Rollback Transaction

	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '2','PurgeInventoryTables', ' Fails to delete record from SKUxLOC table')
END
ELSE
BEGIN
	commit Transaction
	
	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '2','PurgeInventoryTables', LTRIM(RTRIM(CONVERT(char(5),@v_count))) + ' records are removed from SKUxLOC table succsesfull')

END 

--Delete zero records from LOTXLOCXID table
Begin Transaction  
Set @local_n_err = 0

SELECT @v_count = count(1)	
	FROM LOTXLOCXID
		WHERE QTY = 0
		AND QTYALLOCATED = 0
		AND QTYPICKED = 0
		AND QTYEXPECTED = 0
		AND QTYPICKINPROCESS = 0
		AND (PENDINGMOVEIN = 0 OR (PENDINGMOVEIN <> 0 AND EditDate < (getdate() - @purge_days))) 
		AND EditDate < (getdate() - @purge_days) 


IF @v_count > 0
BEGIN
	DELETE FROM LOTXLOCXID
		WHERE QTY = 0
		AND QTYALLOCATED = 0
		AND QTYPICKED = 0
		AND QTYEXPECTED = 0
		AND QTYPICKINPROCESS = 0
		AND (PENDINGMOVEIN = 0 OR (PENDINGMOVEIN <> 0 AND EditDate < (getdate() - @purge_days))) 
		AND EditDate < (getdate() - @purge_days) 

	SET @local_n_err = @@ERROR 
END


IF @local_n_err <> 0 
BEGIN
	Rollback Transaction

	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '3','PurgeInventoryTables', ' Fails to delete record from LOTXLOCXID table')
END
ELSE
BEGIN
	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '3','PurgeInventoryTables', LTRIM(RTRIM(CONVERT(char(5),@v_count))) + ' records are removed from LOTXLOCXID table succsesfull')

	commit Transaction
END 

--Delete zero records from LOT table
Begin Transaction
Set @local_n_err = 0
 
SELECT @v_count = count(1)	
	FROM LOT
		WHERE QTY = 0
		AND QTYPREALLOCATED = 0
		AND QTYALLOCATED = 0
		AND QTYPICKED = 0
		AND QTYONHOLD = 0
		AND EditDate < (getdate() - @purge_days) 

IF @v_count > 0
BEGIN
	DELETE FROM LOT
		WHERE QTY = 0
		AND QTYPREALLOCATED = 0
		AND QTYALLOCATED = 0
		AND QTYPICKED = 0
		AND QTYONHOLD = 0
		AND EditDate < (getdate() - @purge_days) 

	SET @local_n_err = @@ERROR 
END

IF @local_n_err <> 0 
BEGIN
	Rollback Transaction

	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '4','PurgeInventoryTables', ' Fails to delete record from LOT table')
END
ELSE
BEGIN
	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '4','PurgeInventoryTables', LTRIM(RTRIM(CONVERT(char(5),@v_count))) + ' records are removed from LOT table succsesfull')

	commit Transaction
END 

--Update PENDINGMOVEIN to 0
Begin Transaction
Set @local_n_err = 0

SELECT @v_count = count(1)	
	FROM LOTXLOCXID
		WHERE PENDINGMOVEIN <> 0
		AND EditDate < (getdate() - @p_pendingmoveindays) 


IF @v_count > 0
BEGIN
 	DELETE FROM LOTXLOCXID
		WHERE PENDINGMOVEIN <> 0
		AND EditDate < (getdate() - @p_pendingmoveindays) 

	SET @local_n_err = @@ERROR 
END

IF @local_n_err <> 0 
BEGIN
	Rollback Transaction

	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '5','PurgeInventoryTables', ' Fails to update PENDINGMOVEIN to 0 in LOTXLOCXID table')
END
ELSE
BEGIN
	INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
    		VALUES(CONVERT(char(17),getdate(),121) + '5','PurgeInventoryTables', LTRIM(RTRIM(CONVERT(char(5),@v_count))) + ' records with pendingmovein <> 0 are updated in LOTXLOCXID table succsesfull')

	commit Transaction
END


Begin Transaction

INSERT INTO ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) 
	VALUES(CONVERT(char(17),getdate(),121) + '6','PurgeInventoryTables','Finish purge process')


SET @local_n_err = @@ERROR 

IF @local_n_err <> 0 
BEGIN
	Rollback Transaction
END
ELSE
BEGIN
	commit Transaction
END 

GO
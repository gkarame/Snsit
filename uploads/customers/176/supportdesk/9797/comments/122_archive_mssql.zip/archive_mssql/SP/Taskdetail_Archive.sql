-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	Taskdetail table archive table archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE Taskdetail_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveTaskdetailNumber int
Declare @ArchiveTaskdetailTotalNumber int
Declare @ArchiveTaskdetailFailTotalNumber int
Declare @Taskdetail_rowcount1 int
Declare @Taskdetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxTaskdetailKey        varchar (10)
Declare @MinTaskdetailKey        varchar (10)

-- Set Values
Set @n_continue = 1
Set @ArchiveTaskdetailTotalNumber = 0
Set @ArchiveTaskdetailFailTotalNumber = 0
Set @MaxTaskdetailKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'Taskdetail'

Set @local_c_msg =  'Taskdetail Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Taskdetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Taskdetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END
	
--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveTaskdetailNumber = 0
	Set @Taskdetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 Taskdetail records at a time into a archive table
	SELECT	TOP 200 * 
	INTO	#Taskdetail
	FROM	!PROD_DB!.!PROD_WH!.Taskdetail
	WHERE	ADDDATE < (getdate()-@Arc_days) AND STATUS = '9'
	AND TaskdetailKEY > @MaxTaskdetailKey
	ORDER BY TaskdetailKEY
	
	SET @Taskdetail_rowcount1 = @@rowcount

	IF @Taskdetail_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #Taskdetail
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxTaskdetailKey in this batch
	SELECT @MaxTaskdetailKey = MAX(TaskdetailKEY), @MinTaskdetailKey = MIN(TaskdetailKEY) FROM #Taskdetail
		
	--Insert rows into arhive Taskdetail table	
	INSERT INTO !ARC_DB!.!ARC_WH!.Taskdetail 
		SELECT * FROM #Taskdetail
	
	SET @Taskdetail_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@Taskdetail_rowcount1 <> @Taskdetail_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT Taskdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'

	END 
		 
	--Delete rows for production Taskdetail table
	IF (@n_continue <> 3)
	BEGIN

		Delete From !PROD_DB!.!PROD_WH!.Taskdetail 
			where exists (select TaskdetailKEY from #Taskdetail where #Taskdetail.Taskdetailkey =  !PROD_DB!.!PROD_WH!.Taskdetail.Taskdetailkey)
		
		SET @Taskdetail_rowcount2 = @@rowcount
		SELECT @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Taskdetail_rowcount1 <> @Taskdetail_rowcount2)
		BEGIN 

			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE Taskdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
			--BREAK --break out of loop
		END		
	END	

	Set @Taskdetail_rowcount1 = @Taskdetail_rowcount1

	IF (@n_continue = 3)
	BEGIN

		Rollback Transaction	
		
		Set @ArchiveTaskdetailFailTotalNumber = @ArchiveTaskdetailFailTotalNumber +@ArchiveTaskdetailNumber

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. TaskdetailKey in this batch is ' + @MinTaskdetailKey
		Set @local_c_errmsg = @local_c_errmsg2

		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )

		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	

		commit Transaction

		Set @ArchiveTaskdetailTotalNumber = @ArchiveTaskdetailTotalNumber +@ArchiveTaskdetailNumber
		
		Drop table #Taskdetail
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result

Set @local_c_msg =  'Taskdetail Archived Finish - ' + convert(varchar(10),@ArchiveTaskdetailTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveTaskdetailFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	Orders, OrderDetail, Pickdetail, Preallocatepickdetail, Xpickdetail, OPXSHIPORD and Labelcontainerdetail tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE Orders_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveordersNumber int
Declare @ArchiveordersTotalNumber int
Declare @ArchiveordersFailTotalNumber int
Declare @orders_rowcount1 int
Declare @orders_rowcount2 int
Declare @orderdetail_rowcount1 int
Declare @orderdetail_rowcount2 int
Declare @preallocatepickdetail_rowcount1 int
Declare @preallocatepickdetail_rowcount2 int
Declare @pickdetail_rowcount1 int
Declare @pickdetail_rowcount2 int
Declare @xpickdetail_rowcount1 int
Declare @xpickdetail_rowcount2 int
Declare @OPXSHIPORD_rowcount1 int
Declare @OPXSHIPORD_rowcount2 int
Declare @LABELCONTAINERDETAIL_rowcount1 int
Declare @LABELCONTAINERDETAIL_rowcount2 int
Declare @n_continue 	int
Declare @local_n_err 	int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxordersKey        varchar(10)
Declare @MinordersKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveordersTotalNumber = 0
Set @ArchiveordersFailTotalNumber = 0
Set @MaxordersKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'OrdersARCHIVE'

Set @local_c_msg =  'Orders Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'orders')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive orders table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'orderDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive orderDetail table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'pickDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive pickDetail table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'preallocatepickdetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive preallocatepickdetail table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'xpickdetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive xpickdetail table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'OPXSHIPORD')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive OPXSHIPORD table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Labelcontainerdetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Labelcontainerdetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveordersNumber = 0
	Set @orders_rowcount1 = 0
	Set @orderdetail_rowcount1 = 0
	Set @preallocatepickdetail_rowcount1 = 0
	Set @pickdetail_rowcount1 = 0
	Set @xpickdetail_rowcount1 = 0
	Set @OPXSHIPORD_rowcount1 = 0
	Set @LABELCONTAINERDETAIL_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 orders records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#orders
	FROM	!PROD_DB!.!PROD_WH!.orders
	WHERE STATUS >= '95' and orderdate<(getdate()-@Arc_days) 
	AND orderKEY > @MaxordersKey
	order BY orderKEY
	
	SET @orders_rowcount1 = @@rowcount

	IF @orders_rowcount1 = 0
	BEGIN
		Rollback Transaction --Drop table #orders
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxordersKey in this batch
	SELECT @MaxordersKey = MAX(orderKEY), @MinordersKey = MIN(orderKEY) FROM #orders
		
	--Insert rows into arhive orders table	
	INSERT INTO !ARC_DB!.!ARC_WH!.orders SELECT * FROM #orders
	
	SET @orders_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@orders_rowcount1 <> @orders_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT orders failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive orderDetail table
	SELECT	*
	INTO	#orderDetail
	FROM	!PROD_DB!.!PROD_WH!.orderDetail
	WHERE EXISTS (SELECT orderKey from #orders WHERE #orders.orderKey = !PROD_DB!.!PROD_WH!.orderDetail.orderKey);
	
	SET @orderdetail_rowcount1 = @@rowcount

	IF @orderdetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.orderDetail SELECT * FROM #orderDetail

		SET @orderdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@orderdetail_rowcount1 <> @orderdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT orderDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive pickdetail table
	SELECT	*
	INTO	#pickdetail
	FROM	!PROD_DB!.!PROD_WH!.pickdetail
	WHERE EXISTS (SELECT orderKey from #orders WHERE #orders.orderKey = !PROD_DB!.!PROD_WH!.pickdetail.orderKey);
	
	SET @pickdetail_rowcount1 = @@rowcount

	IF @pickdetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.pickdetail SELECT * FROM #pickdetail

		SET @pickdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@pickdetail_rowcount1 <> @pickdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT pickdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive preallocatepickdetail table
	SELECT	*
	INTO	#preallocatepickdetail
	FROM	!PROD_DB!.!PROD_WH!.preallocatepickdetail
	WHERE EXISTS (SELECT orderKey from #orders WHERE #orders.orderKey = !PROD_DB!.!PROD_WH!.preallocatepickdetail.orderKey);
	
	SET @preallocatepickdetail_rowcount1 = @@rowcount

	IF @preallocatepickdetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.preallocatepickdetail SELECT * FROM #preallocatepickdetail

		SET @preallocatepickdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@preallocatepickdetail_rowcount1 <> @preallocatepickdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT preallocatepickdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive xpickdetail table
	SELECT	*
	INTO	#xpickdetail
	FROM	!PROD_DB!.!PROD_WH!.xpickdetail
	WHERE EXISTS (SELECT orderKey from #orders WHERE #orders.orderKey = !PROD_DB!.!PROD_WH!.xpickdetail.orderKey);
	
	SET @xpickdetail_rowcount1 = @@rowcount

	IF @xpickdetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.xpickdetail SELECT * FROM #xpickdetail

		SET @xpickdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@xpickdetail_rowcount1 <> @xpickdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT xpickdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive OPXSHIPORD table
	SELECT	*
	INTO	#OPXSHIPORD
	FROM	!PROD_DB!.!PROD_WH!.OPXSHIPORD
	WHERE EXISTS (SELECT orderKey from #orders WHERE #orders.orderKey = !PROD_DB!.!PROD_WH!.OPXSHIPORD.orderKey);
	
	SET @OPXSHIPORD_rowcount1 = @@rowcount

	IF @OPXSHIPORD_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.OPXSHIPORD SELECT * FROM #OPXSHIPORD

		SET @OPXSHIPORD_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@OPXSHIPORD_rowcount1 <> @OPXSHIPORD_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT OPXSHIPORD failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive LABELCONTAINERDETAIL table
	SELECT	*
	INTO	#LABELCONTAINERDETAIL
	FROM	!PROD_DB!.!PROD_WH!.LABELCONTAINERDETAIL
	WHERE EXISTS (SELECT pickdetailKey from #pickdetail WHERE #pickdetail.pickdetailKey = !PROD_DB!.!PROD_WH!.LABELCONTAINERDETAIL.pickdetailKey);
	
	SET @LABELCONTAINERDETAIL_rowcount1 = @@rowcount

	IF @LABELCONTAINERDETAIL_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.LABELCONTAINERDETAIL SELECT * FROM #LABELCONTAINERDETAIL

		SET @LABELCONTAINERDETAIL_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LABELCONTAINERDETAIL_rowcount1 <> @LABELCONTAINERDETAIL_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT LABELCONTAINERDETAIL failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END			 

	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production LABELCONTAINERDETAIL table
		Delete From !PROD_DB!.!PROD_WH!.LABELCONTAINERDETAIL
			WHERE EXISTS (SELECT pickdetailKey from #pickdetail WHERE #pickdetail.pickdetailKey = !PROD_DB!.!PROD_WH!.LABELCONTAINERDETAIL.pickdetailKey);

		SET @LABELCONTAINERDETAIL_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LABELCONTAINERDETAIL_rowcount1 <> @LABELCONTAINERDETAIL_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete LABELCONTAINERDETAIL failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production OPXSHIPORD table
		Delete From !PROD_DB!.!PROD_WH!.OPXSHIPORD
			where exists (select orderKEY from #orders where #orders.orderkey =  !PROD_DB!.!PROD_WH!.OPXSHIPORD.orderkey)

		SET @OPXSHIPORD_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@OPXSHIPORD_rowcount1 <> @OPXSHIPORD_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete OPXSHIPORD failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production pickdetail table
		Delete From !PROD_DB!.!PROD_WH!.pickdetail
			where exists (select orderKEY from #orders where #orders.orderkey =  !PROD_DB!.!PROD_WH!.pickdetail.orderkey)

		SET @pickdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@pickdetail_rowcount1 <> @pickdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete pickdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production preallocatepickdetail table
		Delete From !PROD_DB!.!PROD_WH!.preallocatepickdetail
			where exists (select orderKEY from #orders where #orders.orderkey =  !PROD_DB!.!PROD_WH!.preallocatepickdetail.orderkey)

		SET @preallocatepickdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@preallocatepickdetail_rowcount1 <> @preallocatepickdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete preallocatepickdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production xpickdetail table
		Delete From !PROD_DB!.!PROD_WH!.xpickdetail 
			where exists (select orderKEY from #orders where #orders.orderkey =  !PROD_DB!.!PROD_WH!.xpickdetail.orderkey)

		SET @xpickdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@xpickdetail_rowcount1 <> @xpickdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete xpickdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production orderDetail table
		Delete From !PROD_DB!.!PROD_WH!.orderDetail 
			where exists (select orderKEY from #orders where #orders.orderkey =  !PROD_DB!.!PROD_WH!.orderDetail.orderkey)

		SET @orderdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@orderdetail_rowcount1 <> @orderdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete orderDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production orders table
		Delete From !PROD_DB!.!PROD_WH!.orders 
			where exists (select orderKEY from #orders where #orders.orderkey =  !PROD_DB!.!PROD_WH!.orders.orderkey)
		
		SET @orders_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@orders_rowcount1 <> @orders_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE orders failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveordersNumber = @orders_rowcount1 + @orderdetail_rowcount1 + @preallocatepickdetail_rowcount1 + @pickdetail_rowcount1 + @xpickdetail_rowcount1 + @OPXSHIPORD_rowcount1 + @LABELCONTAINERDETAIL_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveordersFailTotalNumber = @ArchiveordersFailTotalNumber + @ArchiveordersNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. ordersKey in this batch is ' + @MinordersKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveordersTotalNumber = @ArchiveordersTotalNumber + @ArchiveordersNumber
		
		--Drop tables
		Drop table #LABELCONTAINERDETAIL

		Drop table #OPXSHIPORD		

		Drop table #pickdetail

		Drop table #xpickdetail

		Drop table #preallocatepickdetail

		Drop table #orderDetail

		Drop table #orders
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'orders Archived Finish - ' + convert(varchar(10),@ArchiveordersTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveordersFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	09/28/06
-- Purpose:	Adjustment and Adjustmentdetail tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE Adjustment_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveordersNumber int
Declare @ArchiveAdjustmentTotalNumber int
Declare @ArchiveAdjustmentFailTotalNumber int
Declare @Adjustment_rowcount1 int
Declare @Adjustment_rowcount2 int
Declare @Adjustmentdetail_rowcount1 int
Declare @Adjustmentdetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxAdjustmentKey        varchar(10)
Declare @MinAdjustmentKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveAdjustmentTotalNumber = 0
Set @ArchiveAdjustmentFailTotalNumber = 0
Set @MaxAdjustmentKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'AdjustmentARCHIVE'

Set @local_c_msg =  'Adjustment Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Adjustment')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Adjustment table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Adjustmentdetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Adjustmentdetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END	

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveordersNumber = 0
	Set @Adjustment_rowcount1 = 0
	Set @Adjustmentdetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 Adjustment records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#Adjustment
	FROM	!PROD_DB!.!PROD_WH!.Adjustment
	WHERE effectivedate < (getdate()-@Arc_days) 
	AND AdjustmentKEY > @MaxAdjustmentKey
	ORDER BY AdjustmentKEY
	
	SET @Adjustment_rowcount1 = @@rowcount

	IF @Adjustment_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #Adjustment
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxAdjustmentKey in this batch
	SELECT @MaxAdjustmentKey = MAX(AdjustmentKEY), @MinAdjustmentKey = MIN(AdjustmentKEY) FROM #Adjustment
		
	--Insert rows into arhive Adjustment table	
	INSERT INTO !ARC_DB!.!ARC_WH!.Adjustment SELECT * FROM #Adjustment
	
	SET @Adjustment_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@Adjustment_rowcount1 <> @Adjustment_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT Adjustment failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive Adjustmentdetail table
	SELECT	*
	INTO	#Adjustmentdetail
	FROM	!PROD_DB!.!PROD_WH!.Adjustmentdetail
	WHERE EXISTS (SELECT AdjustmentKey from #Adjustment WHERE #Adjustment.AdjustmentKey = !PROD_DB!.!PROD_WH!.Adjustmentdetail.AdjustmentKey);
	
	SET @Adjustmentdetail_rowcount1 = @@rowcount

	IF @Adjustmentdetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.Adjustmentdetail SELECT * FROM #Adjustmentdetail

		SET @Adjustmentdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Adjustmentdetail_rowcount1 <> @Adjustmentdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT Adjustmentdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production Adjustmentdetail table
		Delete From !PROD_DB!.!PROD_WH!.Adjustmentdetail 
			where exists (select AdjustmentKEY from #Adjustment where #Adjustment.Adjustmentkey =  !PROD_DB!.!PROD_WH!.Adjustmentdetail.Adjustmentkey)

		SET @Adjustmentdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Adjustmentdetail_rowcount1 <> @Adjustmentdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete Adjustmentdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production Adjustment table
		Delete From !PROD_DB!.!PROD_WH!.Adjustment 
			where exists (select AdjustmentKEY from #Adjustment where #Adjustment.Adjustmentkey =  !PROD_DB!.!PROD_WH!.Adjustment.Adjustmentkey)
		
		SET @Adjustment_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Adjustment_rowcount1 <> @Adjustment_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE Adjustment failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveordersNumber = @Adjustment_rowcount1 + @Adjustmentdetail_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveAdjustmentFailTotalNumber = @ArchiveAdjustmentFailTotalNumber + @ArchiveordersNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. AdjustmentKey in this batch is ' + @MinAdjustmentKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveAdjustmentTotalNumber = @ArchiveAdjustmentTotalNumber + @ArchiveordersNumber 

		--Drop tables
		Drop table #Adjustmentdetail

		Drop table #Adjustment
	END	

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'Adjustment Archived Finish - ' + convert(varchar(10),@ArchiveAdjustmentTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveAdjustmentFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	TransASN and TransASND tables archive
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE TransASN_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveTransASNNumber int
Declare @ArchiveTransASNTotalNumber int
Declare @ArchiveTransASNFailTotalNumber int
Declare @TransASN_rowcount1 int
Declare @TransASN_rowcount2 int
Declare @TransASND_rowcount1 int
Declare @TransASND_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxTransASNKey        varchar(10)
Declare @MinTransASNKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveTransASNTotalNumber = 0
Set @ArchiveTransASNFailTotalNumber = 0
Set @MaxTransASNKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'TransASNARCHIVE'

Set @local_c_msg =  'TransASN Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'TransASN')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive TransASN table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'TransASND')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive TransASND table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveTransASNNumber = 0
	Set @TransASN_rowcount1 = 0
	Set @TransASND_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 TransASN records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#TransASN
	FROM	!PROD_DB!.!PROD_WH!.TransASN
	WHERE STATUS = '9' and ADDDATE<(getdate()-@Arc_days) 
	AND TransASNKEY > @MaxTransASNKey
	ORDER BY TransASNKEY
	
	SET @TransASN_rowcount1 = @@rowcount

	IF @TransASN_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #TransASN
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxTransASNKey in this batch
	SELECT @MaxTransASNKey = MAX(TransASNKEY), @MinTransASNKey = MIN(TransASNKEY) FROM #TransASN
		
	--Insert rows into arhive TransASN table	
	INSERT INTO !ARC_DB!.!ARC_WH!.TransASN SELECT * FROM #TransASN
	
	SET @TransASN_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@TransASN_rowcount1 <> @TransASN_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT TransASN failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive TransASND table
	SELECT	*
	INTO	#TransASND
	FROM	!PROD_DB!.!PROD_WH!.TransASND
	WHERE EXISTS (SELECT TransASNKey from #TransASN WHERE #TransASN.TransASNKey = !PROD_DB!.!PROD_WH!.TransASND.TransASNKey);
	
	SET @TransASND_rowcount1 = @@rowcount

	IF @TransASND_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.TransASND SELECT * FROM #TransASND

		SET @TransASND_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@TransASND_rowcount1 <> @TransASND_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT TransASND failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production TransASND table
		Delete From !PROD_DB!.!PROD_WH!.TransASND 
			where exists (select TransASNKEY from #TransASN where #TransASN.TransASNkey =  !PROD_DB!.!PROD_WH!.TransASND.TransASNkey)

		SET @TransASND_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@TransASND_rowcount1 <> @TransASND_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete TransASND failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production TransASN table
		Delete From !PROD_DB!.!PROD_WH!.TransASN 
			where exists (select TransASNKEY from #TransASN where #TransASN.TransASNkey =  !PROD_DB!.!PROD_WH!.TransASN.TransASNkey)
		
		SET @TransASN_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@TransASN_rowcount1 <> @TransASN_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE TransASN failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveTransASNNumber = @TransASN_rowcount1 + @TransASND_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveTransASNFailTotalNumber = @ArchiveTransASNFailTotalNumber + @ArchiveTransASNNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. TransASNKey in this batch is ' + @MinTransASNKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveTransASNTotalNumber = @ArchiveTransASNTotalNumber + @ArchiveTransASNNumber
	
		--Drop tables
		Drop table #TransASND

		Drop table #TransASN
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'TransASN Archived Finish - ' + convert(varchar(10),@ArchiveTransASNTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveTransASNFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	TransShip and TransDetail tables archive
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE TransShip_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveTransShipNumber int
Declare @ArchiveTransShipTotalNumber int
Declare @ArchiveTransShipFailTotalNumber int
Declare @TransShip_rowcount1 int
Declare @TransShip_rowcount2 int
Declare @TransDetail_rowcount1 int
Declare @TransDetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxTransShipKey        varchar(10)
Declare @MinTransShipKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveTransShipTotalNumber = 0
Set @ArchiveTransShipFailTotalNumber = 0
Set @MaxTransShipKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'TransShipARCHIVE'

Set @local_c_msg =  'TransShip Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'TransShip')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive TransShip table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'TransDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive TransDetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveTransShipNumber = 0
	Set @TransShip_rowcount1 = 0
	Set @TransDetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 TransShip records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#TransShip
	FROM	!PROD_DB!.!PROD_WH!.TransShip
	WHERE STATUS = '9' and ADDDATE<(getdate()-@Arc_days) 
	AND TransShipKEY > @MaxTransShipKey
	ORDER BY TransShipKEY
	
	SET @TransShip_rowcount1 = @@rowcount

	IF @TransShip_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #TransShip
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxTransShipKey in this batch
	SELECT @MaxTransShipKey = MAX(TransShipKEY), @MinTransShipKey = MIN(TransShipKEY) FROM #TransShip
		
	--Insert rows into arhive TransShip table	
	INSERT INTO !ARC_DB!.!ARC_WH!.TransShip SELECT * FROM #TransShip
	
	SET @TransShip_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@TransShip_rowcount1 <> @TransShip_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT TransShip failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive TransDetail table
	SELECT	*
	INTO	#TransDetail
	FROM	!PROD_DB!.!PROD_WH!.TransDetail
	WHERE EXISTS (SELECT TransShipKey from #TransShip WHERE #TransShip.TransShipKey = !PROD_DB!.!PROD_WH!.TransDetail.TransShipKey);
	
	SET @TransDetail_rowcount1 = @@rowcount

	IF @TransDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.TransDetail SELECT * FROM #TransDetail

		SET @TransDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@TransDetail_rowcount1 <> @TransDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT TransDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production TransDetail table
		Delete From !PROD_DB!.!PROD_WH!.TransDetail 
			where exists (select TransShipKEY from #TransShip where #TransShip.TransShipkey =  !PROD_DB!.!PROD_WH!.TransDetail.TransShipkey)

		SET @TransDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@TransDetail_rowcount1 <> @TransDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete TransDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production TransShip table
		Delete From !PROD_DB!.!PROD_WH!.TransShip 
			where exists (select TransShipKEY from #TransShip where #TransShip.TransShipkey =  !PROD_DB!.!PROD_WH!.TransShip.TransShipkey)
		
		SET @TransShip_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@TransShip_rowcount1 <> @TransShip_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE TransShip failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveTransShipNumber = @TransShip_rowcount1 + @TransDetail_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveTransShipFailTotalNumber = @ArchiveTransShipFailTotalNumber + @ArchiveTransShipNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. TransShipKey in this batch is ' + @MinTransShipKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveTransShipTotalNumber = @ArchiveTransShipTotalNumber + @ArchiveTransShipNumber
	
		--Drop tables
		Drop table #TransDetail

		Drop table #TransShip
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'TransShip Archived Finish - ' + convert(varchar(10),@ArchiveTransShipTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveTransShipFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

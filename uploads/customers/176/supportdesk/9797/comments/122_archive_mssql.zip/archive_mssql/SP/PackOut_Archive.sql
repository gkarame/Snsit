-------------------------------------------------------------------
-- Programmer:	Anand Vanapalli
-- Created:	04/14/10
-- Purpose:	PACKOUT and PACKOUTDetail tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE PackOut_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveordersNumber int
Declare @ArchivePACKOUTTotalNumber int
Declare @ArchivePACKOUTFailTotalNumber int
Declare @PACKOUT_rowcount1 int
Declare @PACKOUT_rowcount2 int
Declare @PACKOUTDetail_rowcount1 int
Declare @PACKOUTDetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxPACKOUT        varchar(10)
Declare @MinPACKOUT        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchivePACKOUTTotalNumber = 0
Set @ArchivePACKOUTFailTotalNumber = 0
Set @MaxPACKOUT = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'PACKOUTARCHIVE'

Set @local_c_msg =  'PACKOUT Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'PACKOUT')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive PACKOUT table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'PACKOUTDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive PACKOUTDetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveordersNumber = 0
	Set @PACKOUT_rowcount1 = 0
	Set @PACKOUTDetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 PACKOUT records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#PACKOUT
	FROM	!PROD_DB!.!PROD_WH!.PACKOUT PACKOUT
	WHERE PACKOUT.status = '9' and PACKOUT.ADDDATE<(getdate()-@Arc_days)
	AND NOT EXISTS (select 1 from PACKOUTDETAIL where PACKOUTDETAIL.PackOutKey = PACKOUT.PackOutKey) 
	AND PackOutKey > @MaxPACKOUT
	ORDER BY PackOutKey
	
	SET @PACKOUT_rowcount1 = @@rowcount

	IF @PACKOUT_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #PACKOUT
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxPACKOUT in this batch
	SELECT @MaxPACKOUT = MAX(PACKOUTKEY), @MinPACKOUT = MIN(PACKOUTKEy) FROM #PACKOUT
	
	--Insert rows into arhive PACKOUT table	
	INSERT INTO !ARC_DB!.!ARC_WH!.PACKOUT SELECT * FROM #PACKOUT
	
	SET @PACKOUT_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@PACKOUT_rowcount1 <> @PACKOUT_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT PACKOUT failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive PACKOUTDetail table
	SELECT	*
	INTO	#PACKOUTDetail
	FROM	!PROD_DB!.!PROD_WH!.PACKOUTDetail
	WHERE EXISTS (SELECT PACKOUT from #PACKOUT WHERE #PACKOUT.PACKOUTKEY = !PROD_DB!.!PROD_WH!.PACKOUTDetail.PACKOUTKEY);
	
	SET @PACKOUTDetail_rowcount1 = @@rowcount

	IF @PACKOUTDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.PACKOUTDetail SELECT * FROM #PACKOUTDetail

		SET @PACKOUTDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@PACKOUTDetail_rowcount1 <> @PACKOUTDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT PACKOUTDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production PACKOUTDetail table
		Delete From !PROD_DB!.!PROD_WH!.PACKOUTDetail 
			where exists (select PACKOUTKEY from #PACKOUT where #PACKOUT.PACKOUTKEY =  !PROD_DB!.!PROD_WH!.PACKOUTDetail.PACKOUTKEY)

		SET @PACKOUTDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@PACKOUTDetail_rowcount1 <> @PACKOUTDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete PACKOUTDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production PACKOUT table
		Delete From !PROD_DB!.!PROD_WH!.PACKOUT 
			where exists (select PACKOUTKEY from #PACKOUT where #PACKOUT.PACKOUT =  !PROD_DB!.!PROD_WH!.PACKOUT.PACKOUTKEY)
		
		SET @PACKOUT_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@PACKOUT_rowcount1 <> @PACKOUT_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE PACKOUT failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveordersNumber = @PACKOUT_rowcount1 + @PACKOUTDetail_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchivePACKOUTFailTotalNumber = @ArchivePACKOUTFailTotalNumber + @ArchiveordersNumber

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. PACKOUT in this batch is ' + @MinPACKOUT
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchivePACKOUTTotalNumber = @ArchivePACKOUTTotalNumber + @ArchiveordersNumber

		--Drop tables
		Drop table #PACKOUTDetail

		Drop table #PACKOUT
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'PACKOUT Archived Finish - ' + convert(varchar(10),@ArchivePACKOUTTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchivePACKOUTFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

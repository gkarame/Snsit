-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	09/28/06
-- Purpose:	Wave and WaveDetail tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE WAVE_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveWaveNumber int
Declare @ArchiveWaveTotalNumber int
Declare @ArchiveWaveFailTotalNumber int
Declare @Wave_rowcount1 int
Declare @Wave_rowcount2 int
Declare @WaveDetail_rowcount1 int
Declare @WaveDetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxWaveKey        varchar(10)
Declare @MinWaveKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveWaveTotalNumber = 0
Set @ArchiveWaveFailTotalNumber = 0
Set @MaxWaveKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'WaveARCHIVE'

Set @local_c_msg =  'Wave Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Wave')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Wave table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'WaveDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive WaveDetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveWaveNumber = 0
	Set @Wave_rowcount1 = 0
	Set @WaveDetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 Wave records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#Wave
	FROM	!PROD_DB!.!PROD_WH!.Wave
	WHERE STATUS = '9' and ADDDATE<(getdate()-@Arc_days) 
	AND WaveKEY > @MaxWaveKey
	ORDER BY WaveKEY
	
	SET @Wave_rowcount1 = @@rowcount

	IF @Wave_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #Wave
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxWaveKey in this batch
	SELECT @MaxWaveKey = MAX(WaveKEY), @MinWaveKey = MIN(WaveKEY) FROM #Wave
		
	--Insert rows into arhive Wave table	
	INSERT INTO !ARC_DB!.!ARC_WH!.Wave SELECT * FROM #Wave
	
	SET @Wave_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@Wave_rowcount1 <> @Wave_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT Wave failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive WaveDetail table
	SELECT	*
	INTO	#WaveDetail
	FROM	!PROD_DB!.!PROD_WH!.WaveDetail
	WHERE EXISTS (SELECT WaveKey from #Wave WHERE #Wave.WaveKey = !PROD_DB!.!PROD_WH!.WaveDetail.WaveKey);
	
	SET @WaveDetail_rowcount1 = @@rowcount

	IF @WaveDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.WaveDetail SELECT * FROM #WaveDetail

		SET @WaveDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@WaveDetail_rowcount1 <> @WaveDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT WaveDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production WaveDetail table
		Delete From !PROD_DB!.!PROD_WH!.WaveDetail 
			where exists (select WaveKEY from #Wave where #Wave.Wavekey =  !PROD_DB!.!PROD_WH!.WaveDetail.Wavekey)

		SET @WaveDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@WaveDetail_rowcount1 <> @WaveDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete WaveDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production Wave table
		Delete From !PROD_DB!.!PROD_WH!.Wave 
			where exists (select WaveKEY from #Wave where #Wave.Wavekey =  !PROD_DB!.!PROD_WH!.Wave.Wavekey)
		
		SET @Wave_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Wave_rowcount1 <> @Wave_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE Wave failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveWaveNumber = @Wave_rowcount1 + @WaveDetail_rowcount1


	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveWaveFailTotalNumber = @ArchiveWaveFailTotalNumber + @ArchiveWaveNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. WaveKey in this batch is ' + @MinWaveKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveWaveTotalNumber = @ArchiveWaveTotalNumber + @ArchiveWaveNumber
		
		--Drop tables
		Drop table #WaveDetail

		Drop table #Wave
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'Wave Archived Finish - ' + convert(varchar(10),@ArchiveWaveTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveWaveFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	Transfer and Transferdetail tables archive
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE Transfer_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveTransferNumber int
Declare @ArchiveTransferTotalNumber int
Declare @ArchiveTransferFailTotalNumber int
Declare @Transfer_rowcount1 int
Declare @Transfer_rowcount2 int
Declare @Transferdetail_rowcount1 int
Declare @Transferdetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxTransferKey        varchar(10)
Declare @MinTransferKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveTransferTotalNumber = 0
Set @ArchiveTransferFailTotalNumber = 0
Set @MaxTransferKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'TransferARCHIVE'

Set @local_c_msg =  'Transfer Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Transfer')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Transfer table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Transferdetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Transferdetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveTransferNumber = 0
	Set @Transfer_rowcount1 = 0
	Set @Transferdetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 Transfer records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#Transfer
	FROM	!PROD_DB!.!PROD_WH!.Transfer
	WHERE STATUS = '9' and effectivedate<(getdate()-@Arc_days) 
	AND TransferKEY > @MaxTransferKey
	ORDER BY TransferKEY
	
	SET @Transfer_rowcount1 = @@rowcount

	IF @Transfer_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #Transfer
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxTransferKey in this batch
	SELECT @MaxTransferKey = MAX(TransferKEY), @MinTransferKey = MIN(TransferKEY) FROM #Transfer
		
	--Insert rows into arhive Transfer table	
	INSERT INTO !ARC_DB!.!ARC_WH!.Transfer SELECT * FROM #Transfer
	
	SET @Transfer_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@Transfer_rowcount1 <> @Transfer_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT Transfer failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive Transferdetail table
	SELECT	*
	INTO	#Transferdetail
	FROM	!PROD_DB!.!PROD_WH!.Transferdetail
	WHERE EXISTS (SELECT TransferKey from #Transfer WHERE #Transfer.TransferKey = !PROD_DB!.!PROD_WH!.Transferdetail.TransferKey);
	
	SET @Transferdetail_rowcount1 = @@rowcount

	IF @Transferdetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.Transferdetail SELECT * FROM #Transferdetail

		SET @Transferdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Transferdetail_rowcount1 <> @Transferdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT Transferdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production Transferdetail table
		Delete From !PROD_DB!.!PROD_WH!.Transferdetail 
			where exists (select TransferKEY from #Transfer where #Transfer.Transferkey =  !PROD_DB!.!PROD_WH!.Transferdetail.Transferkey)

		SET @Transferdetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Transferdetail_rowcount1 <> @Transferdetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete Transferdetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production Transfer table
		Delete From !PROD_DB!.!PROD_WH!.Transfer 
			where exists (select TransferKEY from #Transfer where #Transfer.Transferkey =  !PROD_DB!.!PROD_WH!.Transfer.Transferkey)
		
		SET @Transfer_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Transfer_rowcount1 <> @Transfer_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE Transfer failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveTransferNumber = @Transfer_rowcount1 + @Transferdetail_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveTransferFailTotalNumber = @ArchiveTransferFailTotalNumber + @ArchiveTransferNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. TransferKey in this batch is ' + @MinTransferKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveTransferTotalNumber = @ArchiveTransferTotalNumber + @ArchiveTransferNumber
	
		--Drop tables
		Drop table #Transferdetail

		Drop table #Transfer
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'Transfer Archived Finish - ' + convert(varchar(10),@ArchiveTransferTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveTransferFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

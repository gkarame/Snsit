-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	09/28/06
-- Purpose:	XOrders and XOrderDetail tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE XOrders_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveXOrdersNumber int
Declare @ArchiveXOrdersTotalNumber int
Declare @ArchiveXOrdersFailTotalNumber int
Declare @XOrders_rowcount1 int
Declare @XOrders_rowcount2 int
Declare @XOrderDetail_rowcount1 int
Declare @XOrderDetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxOrderKey        varchar(10)
Declare @MinOrderKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveXOrdersTotalNumber = 0
Set @ArchiveXOrdersFailTotalNumber = 0
Set @MaxOrderKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'XOrdersARCHIVE'

Set @local_c_msg =  'XOrders Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'XOrders')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive XOrders table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'XOrderDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive XOrderDetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveXOrdersNumber = 0
	Set @XOrders_rowcount1 = 0
	Set @XOrderDetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 XOrders records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#XOrders
	FROM	!PROD_DB!.!PROD_WH!.XOrders
	WHERE STATUS = '9' and ADDDATE<(getdate()-@Arc_days) 
	AND OrderKey > @MaxOrderKey
	ORDER BY OrderKey
	
	SET @XOrders_rowcount1 = @@rowcount

	IF @XOrders_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #XOrders
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxOrderKey in this batch
	SELECT @MaxOrderKey = MAX(OrderKey), @MinOrderKey = MIN(OrderKey) FROM #XOrders
		
	--Insert rows into arhive XOrders table	
	INSERT INTO !ARC_DB!.!ARC_WH!.XOrders SELECT * FROM #XOrders
	
	SET @XOrders_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@XOrders_rowcount1 <> @XOrders_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT XOrders failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive XOrderDetail table
	SELECT	*
	INTO	#XOrderDetail
	FROM	!PROD_DB!.!PROD_WH!.XOrderDetail
	WHERE EXISTS (SELECT OrderKey from #XOrders WHERE #XOrders.OrderKey = !PROD_DB!.!PROD_WH!.XOrderDetail.OrderKey);
	
	SET @XOrderDetail_rowcount1 = @@rowcount

	IF @XOrderDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.XOrderDetail SELECT * FROM #XOrderDetail

		SET @XOrderDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@XOrderDetail_rowcount1 <> @XOrderDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT XOrderDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production XOrderDetail table
		Delete From !PROD_DB!.!PROD_WH!.XOrderDetail 
			where exists (select OrderKey from #XOrders where #XOrders.OrderKey =  !PROD_DB!.!PROD_WH!.XOrderDetail.OrderKey)

		SET @XOrderDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@XOrderDetail_rowcount1 <> @XOrderDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete XOrderDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production XOrders table
		Delete From !PROD_DB!.!PROD_WH!.XOrders 
			where exists (select OrderKey from #XOrders where #XOrders.OrderKey =  !PROD_DB!.!PROD_WH!.XOrders.OrderKey)
		
		SET @XOrders_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@XOrders_rowcount1 <> @XOrders_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE XOrders failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveXOrdersNumber = @XOrders_rowcount1 + @XOrderDetail_rowcount1


	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveXOrdersFailTotalNumber = @ArchiveXOrdersFailTotalNumber + @ArchiveXOrdersNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. OrderKey in this batch is ' + @MinOrderKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveXOrdersTotalNumber = @ArchiveXOrdersTotalNumber + @ArchiveXOrdersNumber
		
		--Drop tables
		Drop table #XOrderDetail

		Drop table #XOrders
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'XOrders Archived Finish - ' + convert(varchar(10),@ArchiveXOrdersTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveXOrdersFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

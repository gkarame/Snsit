-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	LoadHDR, LoadStop, LoadStopSeal, LoadUnitDetail and LoadOrderDetail tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE LoadHDR_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveLoadHDRNumber int
Declare @ArchiveLoadHDRTotalNumber int
Declare @ArchiveLoadHDRFailTotalNumber int
Declare @LoadHDR_rowcount1 int
Declare @LoadHDR_rowcount2 int
Declare @LoadStop_rowcount1 int
Declare @LoadStop_rowcount2 int
Declare @LoadStopSeal_rowcount1 int
Declare @LoadStopSeal_rowcount2 int
Declare @LoadUnitDetail_rowcount1 int
Declare @LoadUnitDetail_rowcount2 int
Declare @LoadOrderDetail_rowcount1 int
Declare @LoadOrderDetail_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxLOADID        varchar (10)
Declare @MinLOADID        varchar (10)

-- Set Values
Set @n_continue = 1
Set @ArchiveLoadHDRTotalNumber = 0
Set @ArchiveLoadHDRFailTotalNumber = 0
Set @MaxLOADID = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'LoadHDRARCHIVE'

Set @local_c_msg =  'LoadHDR Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'LoadHDR')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive LoadHDR table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'LoadStop')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive LoadStop table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'LoadStopSeal')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive LoadStopSeal table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'LoadUnitDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive LoadUnitDetail table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'LoadOrderDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive LoadOrderDetail table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveLoadHDRNumber = 0
	Set @LoadHDR_rowcount1 = 0
	Set @LoadStop_rowcount1 = 0
	Set @LoadStopSeal_rowcount1 = 0
	Set @LoadUnitDetail_rowcount1 = 0
	Set @LoadOrderDetail_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 LoadHDR records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#LoadHDR
	FROM	!PROD_DB!.!PROD_WH!.LoadHDR
	WHERE	ADDDATE < (getdate()-@Arc_days) AND STATUS = '15'
	AND LOADID > @MaxLOADID
	ORDER BY LOADID
	
	SET @LoadHDR_rowcount1 = @@rowcount

	IF @LoadHDR_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #LoadHDR
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxLOADID in this batch
	SELECT @MaxLOADID = MAX(LOADID), @MinLOADID = MIN(LOADID) FROM #LoadHDR
		
	--Insert rows into arhive LoadHDR table	
	INSERT INTO !ARC_DB!.!ARC_WH!.LoadHDR SELECT * FROM #LoadHDR
	
	SET @LoadHDR_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@LoadHDR_rowcount1 <> @LoadHDR_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT LoadHDR failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive LoadStop table
	SELECT	*
	INTO	#LoadStop
	FROM	!PROD_DB!.!PROD_WH!.LoadStop
	WHERE EXISTS (SELECT LOADID from #LoadHDR WHERE #LoadHDR.LOADID = !PROD_DB!.!PROD_WH!.LoadStop.LOADID);
	
	SET @LoadStop_rowcount1 = @@rowcount

	IF @LoadStop_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.LoadStop SELECT * FROM #LoadStop

		SET @LoadStop_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadStop_rowcount1 <> @LoadStop_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT LoadStop failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive LoadStopSeal table
	SELECT	*
	INTO	#LoadStopSeal
	FROM	!PROD_DB!.!PROD_WH!.LoadStopSeal
	WHERE EXISTS (SELECT LOADSTOPID from #LoadStop WHERE #LoadStop.LOADSTOPID = !PROD_DB!.!PROD_WH!.LoadStopSeal.LOADSTOPID);
	
	SET @LoadStopSeal_rowcount1 = @@rowcount

	IF @LoadStopSeal_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.LoadStopSeal SELECT * FROM #LoadStopSeal

		SET @LoadStopSeal_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadStopSeal_rowcount1 <> @LoadStopSeal_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT LoadStopSeal failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive LoadUnitDetail table
	SELECT	*
	INTO	#LoadUnitDetail
	FROM	!PROD_DB!.!PROD_WH!.LoadUnitDetail
	WHERE EXISTS (SELECT LOADSTOPID from #LoadStop WHERE #LoadStop.LOADSTOPID = !PROD_DB!.!PROD_WH!.LoadUnitDetail.LOADSTOPID);
	
	SET @LoadUnitDetail_rowcount1 = @@rowcount

	IF @LoadUnitDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.LoadUnitDetail SELECT * FROM #LoadUnitDetail

		SET @LoadUnitDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadUnitDetail_rowcount1 <> @LoadUnitDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT LoadUnitDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive LoadOrderDetail table
	SELECT	*
	INTO	#LoadOrderDetail
	FROM	!PROD_DB!.!PROD_WH!.LoadOrderDetail
	WHERE EXISTS (SELECT LOADSTOPID from #LoadStop WHERE #LoadStop.LOADSTOPID = !PROD_DB!.!PROD_WH!.LoadOrderDetail.LOADSTOPID);
	
	SET @LoadOrderDetail_rowcount1 = @@rowcount

	IF @LoadOrderDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.LoadOrderDetail SELECT * FROM #LoadOrderDetail

		SET @LoadOrderDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadOrderDetail_rowcount1 <> @LoadOrderDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT LoadOrderDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production LoadUnitDetail table
		Delete From !PROD_DB!.!PROD_WH!.LoadUnitDetail 
			where exists (select LOADSTOPID from #LoadStop where #LoadStop.LOADSTOPID =  !PROD_DB!.!PROD_WH!.LoadUnitDetail.LOADSTOPID)

		SET @LoadUnitDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadUnitDetail_rowcount1 <> @LoadUnitDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete LoadUnitDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production LoadOrderDetail table
		Delete From !PROD_DB!.!PROD_WH!.LoadOrderDetail 
			where exists (select LOADSTOPID from #LoadStop where #LoadStop.LOADSTOPID =  !PROD_DB!.!PROD_WH!.LoadOrderDetail.LOADSTOPID)

		SET @LoadOrderDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadOrderDetail_rowcount1 <> @LoadOrderDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete LoadOrderDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production LoadStopSeal table
		Delete From !PROD_DB!.!PROD_WH!.LoadStopSeal 
			where exists (select LOADSTOPID from #LoadStop where #LoadStop.LOADSTOPID =  !PROD_DB!.!PROD_WH!.LoadStopSeal.LOADSTOPID)

		SET @LoadStopSeal_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadStopSeal_rowcount1 <> @LoadStopSeal_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete LoadStopSeal failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production LoadStop table
		Delete From !PROD_DB!.!PROD_WH!.LoadStop 
			where exists (select LOADID from #LoadHDR where #LoadHDR.LOADID =  !PROD_DB!.!PROD_WH!.LoadStop.LOADID)

		SET @LoadStop_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadStop_rowcount1 <> @LoadStop_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete LoadStop failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production LoadHDR table
		Delete From !PROD_DB!.!PROD_WH!.LoadHDR 
			where exists (select LOADID from #LoadHDR where #LoadHDR.LOADID =  !PROD_DB!.!PROD_WH!.LoadHDR.LOADID)
		
		SET @LoadHDR_rowcount2 = @@rowcount
		SELECT @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LoadHDR_rowcount1 <> @LoadHDR_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE LoadHDR failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveLoadHDRNumber = @LoadHDR_rowcount1 + @LoadStop_rowcount1 + @LoadStopSeal_rowcount1 + @LoadUnitDetail_rowcount1 + @LoadOrderDetail_rowcount1

	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveLoadHDRFailTotalNumber = @ArchiveLoadHDRFailTotalNumber + @ArchiveLoadHDRNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. LOADID in this batch is ' + @MinLOADID
		Set @local_c_errmsg = @local_c_errmsg2
			
		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		
		
		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveLoadHDRTotalNumber = @ArchiveLoadHDRTotalNumber + @ArchiveLoadHDRNumber
	

		--Drop tables
		Drop table #LoadOrderDetail

		Drop table #LoadUnitDetail

		Drop table #LoadStopSeal

		Drop table #LoadStop

		Drop table #LoadHDR
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'LoadHDR Archived Finish - ' + convert(varchar(10),@ArchiveLoadHDRTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveLoadHDRFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

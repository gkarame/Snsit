-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	06/19/09
-- Purpose:	WP_Wave and WP_WaveDetailsS table archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Note:
-- Replace the following !variables! with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse schema name (e.g. warehse1 or warehse2)
-- !PROD_WP! 	--Source Waveplan schema name (e.g. wpuser)
-- !ARC_DB!	--Archive database  (e.g. ARC1)
-- !ARC_WH! 	--Archive warehouse schema name (e.g. warehse1 or warehse2)
-- !ARC_WP! 	--Archive Waveplan schema name (e.g. wpuser)

-- @Arc_days 	--Days you want to keep in source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE SPWP_WaveArchive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveWP_WaveNumber int
Declare @ArchiveWP_WaveTotalNumber int
Declare @ArchiveWP_WaveFailTotalNumber int
Declare @WP_Wave_rowcount1 int
Declare @WP_Wave_rowcount2 int
Declare @WP_WaveDetails_rowcount1 int
Declare @WP_WaveDetails_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxWP_WaveKey        varchar(10)
Declare @MinWP_WaveKey        varchar(10)

-- Set Values
Set @n_continue = 1
Set @ArchiveWP_WaveTotalNumber = 0
Set @ArchiveWP_WaveFailTotalNumber = 0
Set @MaxWP_WaveKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'WP_WaveARCHIVE'

Set @local_c_msg =  'WP_Wave Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'WP_Wave')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive WP_Wave table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'WP_WaveDetails')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive WP_WaveDetails table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveWP_WaveNumber = 0
	Set @WP_Wave_rowcount1 = 0
	Set @WP_WaveDetails_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 WP_Wave records at a time into a archive table
        --remove all record in wave plan db if it does not exist in warehous db
	SELECT	TOP 200 *
	INTO	#WP_Wave
	FROM	!PROD_DB!.!PROD_WP!.WP_Wave A    --wave plan db table
	WHERE NOT EXISTS (SELECT B.WaveKey from !PROD_DB!.!PROD_WH!.WAVE B WHERE B.WAVEKEY = A.WMSWAVEID)  --warehous db table
        AND A.WHSEID = '!PROD_WH!' 
	AND A.WMSWAVEID > @MaxWP_WaveKey
	AND A.createdon<(getdate()-@Arc_days)           
	ORDER BY A.WMSWAVEID
	
	SET @WP_Wave_rowcount1 = @@rowcount

	IF @WP_Wave_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #WP_Wave
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxWP_WaveKey in this batch
	SELECT @MaxWP_WaveKey = MAX(WMSWAVEID), @MinWP_WaveKey = MIN(WMSWAVEID) FROM #WP_Wave
		
	--Insert rows into arhive WP_Wave table	
	INSERT INTO !ARC_DB!.!ARC_WP!.WP_Wave SELECT * FROM #WP_Wave
	
	SET @WP_Wave_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@WP_Wave_rowcount1 <> @WP_Wave_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT WP_Wave failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive WP_WaveDetails table
	SELECT	*
	INTO	#WP_WaveDetails
	FROM	!PROD_DB!.!PROD_WP!.WP_WaveDetails A
	WHERE EXISTS (SELECT #WP_Wave.WMSWAVEID from #WP_Wave WHERE #WP_Wave.WAVEKEY = A.WAVEKEY);
	
	SET @WP_WaveDetails_rowcount1 = @@rowcount

	IF @WP_WaveDetails_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WP!.WP_WaveDetails SELECT * FROM #WP_WaveDetails

		SET @WP_WaveDetails_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@WP_WaveDetails_rowcount1 <> @WP_WaveDetails_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT WP_WaveDetails failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production WP_WaveDetails table
		Delete From !PROD_DB!.!PROD_WP!.WP_WaveDetails 
			where exists (select WMSWAVEID from #WP_Wave where #WP_Wave.WAVEKEY =  !PROD_DB!.!PROD_WP!.WP_WaveDetails.WAVEKEY)

		SET @WP_WaveDetails_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@WP_WaveDetails_rowcount1 <> @WP_WaveDetails_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete WP_WaveDetails failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production WP_Wave table
		Delete From !PROD_DB!.!PROD_WP!.WP_Wave 
			where exists (select WMSWAVEID from #WP_Wave where #WP_Wave.WMSWAVEID =  !PROD_DB!.!PROD_WP!.WP_Wave.WMSWAVEID)
		
		SET @WP_Wave_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@WP_Wave_rowcount1 <> @WP_Wave_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE WP_Wave failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

	Set @ArchiveWP_WaveNumber = @WP_Wave_rowcount1 + @WP_WaveDetails_rowcount1


	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveWP_WaveFailTotalNumber = @ArchiveWP_WaveFailTotalNumber + @ArchiveWP_WaveNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. WMSWAVEID in this batch is ' + @MinWP_WaveKey
		Set @local_c_errmsg = @local_c_errmsg2


		INSERT INTO !ARC_DB!.!ARC_WP!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveWP_WaveTotalNumber = @ArchiveWP_WaveTotalNumber + @ArchiveWP_WaveNumber
		
		--Drop tables
		Drop table #WP_WaveDetails

		Drop table #WP_Wave
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'WP_Wave Archived Finish - ' + convert(varchar(10),@ArchiveWP_WaveTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveWP_WaveFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WP!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

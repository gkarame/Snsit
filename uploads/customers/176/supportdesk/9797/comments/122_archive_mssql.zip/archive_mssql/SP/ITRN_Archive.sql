-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	ITRN table archive 
-------------------------------------------------------------------
-- Modification History
-- 11/08/2010 FW Added code to archive itrnserial table
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE ITRN_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveordersNumber int
Declare @ArchiveItrnTotalNumber int
Declare @ArchiveItrnFailTotalNumber int
Declare @itrn_rowcount1 int
Declare @itrn_rowcount2 int
Declare @ItrnSerial_rowcount1 int
Declare @ItrnSerial_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxItrnKey        varchar (10)
Declare @MinItrnKey        varchar (10)

-- Set Values
Set @n_continue = 1
Set @ArchiveItrnTotalNumber = 0
Set @ArchiveItrnFailTotalNumber = 0
Set @MaxItrnKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'ITRN'

Set @local_c_msg =  'ITRN Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'ITRN')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive ITRN table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END
	
--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveordersNumber = 0
	Set @itrn_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 itrn records at a time into a archive table
	SELECT	TOP 200 * 
	INTO	#ITRN
	FROM	!PROD_DB!.!PROD_WH!.ITRN
	WHERE	EFFECTIVEDATE < (getdate()-@Arc_days) 
	AND ITRNKEY > @MaxItrnKey
	ORDER BY ITRNKEY
	
	SET @itrn_rowcount1 = @@rowcount

	IF @itrn_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #ITRN
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxItrnKey in this batch
	SELECT @MaxItrnKey = MAX(ITRNKEY), @MinItrnKey = MIN(ITRNKEY) FROM #ITRN
		
	--Insert rows into arhive Itrn table	
	INSERT INTO !ARC_DB!.!ARC_WH!.ITRN 
		SELECT * FROM #ITRN
	
	SET @itrn_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@itrn_rowcount1 <> @itrn_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT ITRN failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'

	END 

	--Insert rows into arhive ItrnSerial table
	SELECT	*
	INTO	#ItrnSerial
	FROM	!PROD_DB!.!PROD_WH!.ItrnSerial
	WHERE EXISTS (SELECT ITRNKEY from #Itrn WHERE #Itrn.ITRNKEY = !PROD_DB!.!PROD_WH!.ItrnSerial.ITRNKEY);

	SET @ItrnSerial_rowcount1 = @@rowcount

	IF @ItrnSerial_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.ItrnSerial SELECT * FROM #ItrnSerial

		SET @ItrnSerial_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@ItrnSerial_rowcount1 <> @ItrnSerial_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT ItrnSerial failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Delete rows for production ItrnSerial table
	IF (@n_continue <> 3)
	BEGIN
		Delete From !PROD_DB!.!PROD_WH!.ItrnSerial 
			where exists (select ITRNKEY from #ITRN where #Itrn.ITRNKEY =  !PROD_DB!.!PROD_WH!.ItrnSerial.ITRNKEY)

		SET @ItrnSerial_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@ItrnSerial_rowcount1 <> @ItrnSerial_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete ItrnSerial failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 		
	END	
		 
	--Delete rows for production Itrn table
	IF (@n_continue <> 3)
	BEGIN

		Delete From !PROD_DB!.!PROD_WH!.ITRN 
			where exists (select ITRNKEY from #ITRN where #ITRN.itrnkey =  !PROD_DB!.!PROD_WH!.ITRN.itrnkey)
		
		SET @itrn_rowcount2 = @@rowcount
		SELECT @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@itrn_rowcount1 <> @itrn_rowcount2)
		BEGIN 

			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE ITRN failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
			--BREAK --break out of loop
		END		
	END	

	--Update rows for production Lot table
	IF (@n_continue <> 3)
	BEGIN

	    	UPDATE	!PROD_DB!.!PROD_WH!.LOT 
	   	  SET	!PROD_DB!.!PROD_WH!.LOT.ArchiveQty = !PROD_DB!.!PROD_WH!.LOT.ArchiveQty + (select sum(Qty) 
							    	from #ITRN 
								where !PROD_DB!.!PROD_WH!.LOT.Lot = #ITRN.lot 
							     	and #ITRN.TranType != 'MV'
							   	group by #ITRN.lot),
						     !PROD_DB!.!PROD_WH!.LOT.ArchiveDate = (select Max(EFFECTIVEDATE) 
							   	from #ITRN 
							   	where !PROD_DB!.!PROD_WH!.LOT.Lot = #ITRN.lot 
							     	and #ITRN.TranType != 'MV'
							   	group by #ITRN.lot)
		  WHERE  exists 	(select distinct lot 
                                  from #ITRN 
                                  where #ITRN.TranType != 'MV'
			          and #ITRN.LOT  =  !PROD_DB!.!PROD_WH!.LOT.LOT) 
			
		SELECT @local_n_err = @@ERROR

		IF @local_n_err <> 0
		BEGIN 

			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Update Lot  failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
			
		--BREAK --break out of loop
		END
	END

	Set @ArchiveordersNumber = @itrn_rowcount1

	IF (@n_continue = 3)
	BEGIN

		Rollback Transaction	
		
		Set @ArchiveItrnFailTotalNumber = @ArchiveItrnFailTotalNumber + @ArchiveordersNumber

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. ItrnKey in this batch is ' + @MinItrnKey
		Set @local_c_errmsg = @local_c_errmsg2

		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )

		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	

		commit Transaction

		Set @ArchiveItrnTotalNumber = @ArchiveItrnTotalNumber + @ArchiveordersNumber
	
		--Drop table 
		Drop table #ITRN
		Drop table #ItrnSerial
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result

Set @local_c_msg =  'ITRN Archived Finish - ' + convert(varchar(10),@ArchiveITRNTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveITRNFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

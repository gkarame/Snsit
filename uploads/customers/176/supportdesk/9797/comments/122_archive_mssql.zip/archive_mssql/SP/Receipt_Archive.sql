-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	Receipt, ReceiptDetail, LPNDetail, RECEIPTSTATUSHISTORY and RECEIPTDETAILSTATUSHISTORY tables archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE Receipt_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveReceiptNumber int
Declare @ArchiveReceiptTotalNumber int
Declare @ArchiveReceiptFailTotalNumber int
Declare @Receipt_rowcount1 int
Declare @Receipt_rowcount2 int
Declare @ReceiptDetail_rowcount1 int
Declare @ReceiptDetail_rowcount2 int
Declare @LPNDetail_rowcount1 int
Declare @LPNDetail_rowcount2 int
Declare @RECEIPTSTATUSHISTORY_rowcount1 int
Declare @RECEIPTSTATUSHISTORY_rowcount2 int
Declare @RECEIPTDETAILSTATUSHISTORY_rowcount1 int
Declare @RECEIPTDETAILSTATUSHISTORY_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxReceiptKey        varchar (10)
Declare @MinReceiptKey        varchar (10)

-- Set Values
Set @n_continue = 1
Set @ArchiveReceiptTotalNumber = 0
Set @ArchiveReceiptFailTotalNumber = 0
Set @MaxReceiptKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'ReceiptARCHIVE'

Set @local_c_msg =  'Receipt Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'Receipt')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive Receipt table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'ReceiptDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive ReceiptDetail table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'LPNDetail')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive LPNDetail table does not exist.'
END
	
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'RECEIPTSTATUSHISTORY')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive RECEIPTSTATUSHISTORY table does not exist.'
END

IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'RECEIPTDETAILSTATUSHISTORY')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive RECEIPTDETAILSTATUSHISTORY table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END

--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveReceiptNumber = 0
	Set @Receipt_rowcount1 = 0
	Set @ReceiptDetail_rowcount1 = 0
	Set @LPNDetail_rowcount1 = 0
	Set @RECEIPTSTATUSHISTORY_rowcount1 = 0
	Set @RECEIPTDETAILSTATUSHISTORY_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 Receipt records at a time into a archive table
	SELECT	TOP 200 *
	INTO	#Receipt
	FROM	!PROD_DB!.!PROD_WH!.Receipt
	WHERE	ReceiptDate < (getdate()-@Arc_days) AND STATUS = '9'
	AND ReceiptKEY > @MaxReceiptKey
	ORDER BY ReceiptKEY
	
	SET @Receipt_rowcount1 = @@rowcount

	IF @Receipt_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #Receipt
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxReceiptKey in this batch
	SELECT @MaxReceiptKey = MAX(ReceiptKEY), @MinReceiptKey = MIN(ReceiptKEY) FROM #Receipt
		
	--Insert rows into arhive Receipt table	
	INSERT INTO !ARC_DB!.!ARC_WH!.Receipt SELECT * FROM #Receipt
	
	SET @Receipt_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@Receipt_rowcount1 <> @Receipt_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT Receipt failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
	END 

	--Insert rows into archive ReceiptDetail table
	SELECT	*
	INTO	#ReceiptDetail
	FROM	!PROD_DB!.!PROD_WH!.ReceiptDetail
	WHERE EXISTS (SELECT ReceiptKey from #Receipt WHERE #Receipt.ReceiptKey = !PROD_DB!.!PROD_WH!.ReceiptDetail.ReceiptKey);
	
	SET @ReceiptDetail_rowcount1 = @@rowcount

	IF @ReceiptDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.ReceiptDetail SELECT * FROM #ReceiptDetail

		SET @ReceiptDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@ReceiptDetail_rowcount1 <> @ReceiptDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT ReceiptDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive LPNDetail table
	SELECT	*
	INTO	#LPNDetail
	FROM	!PROD_DB!.!PROD_WH!.LPNDetail
	WHERE EXISTS (SELECT ReceiptKey from #Receipt WHERE #Receipt.ReceiptKey = !PROD_DB!.!PROD_WH!.LPNDetail.ReceiptKey);
	
	SET @LPNDetail_rowcount1 = @@rowcount

	IF @LPNDetail_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.LPNDetail SELECT * FROM #LPNDetail

		SET @LPNDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LPNDetail_rowcount1 <> @LPNDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT LPNDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive RECEIPTSTATUSHISTORY table
	SELECT	*
	INTO	#RECEIPTSTATUSHISTORY
	FROM	!PROD_DB!.!PROD_WH!.RECEIPTSTATUSHISTORY
	WHERE EXISTS (SELECT ReceiptKey from #Receipt WHERE #Receipt.ReceiptKey = !PROD_DB!.!PROD_WH!.RECEIPTSTATUSHISTORY.ReceiptKey);
	
	SET @RECEIPTSTATUSHISTORY_rowcount1 = @@rowcount

	IF @RECEIPTSTATUSHISTORY_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.RECEIPTSTATUSHISTORY SELECT * FROM #RECEIPTSTATUSHISTORY

		SET @RECEIPTSTATUSHISTORY_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@RECEIPTSTATUSHISTORY_rowcount1 <> @RECEIPTSTATUSHISTORY_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT RECEIPTSTATUSHISTORY failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END

	--Insert rows into archive RECEIPTDETAILSTATUSHISTORY table
	SELECT	*
	INTO	#RECEIPTDETAILSTATUSHISTORY
	FROM	!PROD_DB!.!PROD_WH!.RECEIPTDETAILSTATUSHISTORY
	WHERE EXISTS (SELECT ReceiptKey from #Receipt WHERE #Receipt.ReceiptKey = !PROD_DB!.!PROD_WH!.RECEIPTDETAILSTATUSHISTORY.ReceiptKey);
	
	SET @RECEIPTDETAILSTATUSHISTORY_rowcount1 = @@rowcount

	IF @RECEIPTDETAILSTATUSHISTORY_rowcount1 > 0
	BEGIN
		INSERT INTO !ARC_DB!.!ARC_WH!.RECEIPTDETAILSTATUSHISTORY SELECT * FROM #RECEIPTDETAILSTATUSHISTORY

		SET @RECEIPTDETAILSTATUSHISTORY_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@RECEIPTDETAILSTATUSHISTORY_rowcount1 <> @RECEIPTDETAILSTATUSHISTORY_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: INSERT RECEIPTDETAILSTATUSHISTORY failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 
	END
		 
	--Delete rows for production table
	IF (@n_continue <> 3)
	BEGIN
		--Delete rows for production RECEIPTSTATUSHISTORY table
		Delete From !PROD_DB!.!PROD_WH!.RECEIPTSTATUSHISTORY 
			where exists (select ReceiptKEY from #Receipt where #Receipt.Receiptkey =  !PROD_DB!.!PROD_WH!.RECEIPTSTATUSHISTORY.Receiptkey)

		SET @RECEIPTSTATUSHISTORY_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@RECEIPTSTATUSHISTORY_rowcount1 <> @RECEIPTSTATUSHISTORY_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete RECEIPTSTATUSHISTORY failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production RECEIPTDETAILSTATUSHISTORY table
		Delete From !PROD_DB!.!PROD_WH!.RECEIPTDETAILSTATUSHISTORY 
			where exists (select ReceiptKEY from #Receipt where #Receipt.Receiptkey =  !PROD_DB!.!PROD_WH!.RECEIPTDETAILSTATUSHISTORY.Receiptkey)

		SET @RECEIPTDETAILSTATUSHISTORY_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@RECEIPTDETAILSTATUSHISTORY_rowcount1 <> @RECEIPTDETAILSTATUSHISTORY_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete RECEIPTDETAILSTATUSHISTORY failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production LPNDetail table
		Delete From !PROD_DB!.!PROD_WH!.LPNDetail 
			where exists (select ReceiptKEY from #Receipt where #Receipt.Receiptkey =  !PROD_DB!.!PROD_WH!.LPNDetail.Receiptkey)

		SET @LPNDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@LPNDetail_rowcount1 <> @LPNDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete LPNDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production ReceiptDetail table
		Delete From !PROD_DB!.!PROD_WH!.ReceiptDetail 
			where exists (select ReceiptKEY from #Receipt where #Receipt.Receiptkey =  !PROD_DB!.!PROD_WH!.ReceiptDetail.Receiptkey)

		SET @ReceiptDetail_rowcount2 = @@rowcount
		SET @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@ReceiptDetail_rowcount1 <> @ReceiptDetail_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: Delete ReceiptDetail failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'
		END 

		--Delete rows for production Receipt table
		Delete From !PROD_DB!.!PROD_WH!.Receipt 
			where exists (select ReceiptKEY from #Receipt where #Receipt.Receiptkey =  !PROD_DB!.!PROD_WH!.Receipt.Receiptkey)
		
		SET @Receipt_rowcount2 = @@rowcount
		SELECT @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@Receipt_rowcount1 <> @Receipt_rowcount2)
		BEGIN 
			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE Receipt failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
		END		
	END	

        Set @ArchiveReceiptNumber = @Receipt_rowcount1 + @ReceiptDetail_rowcount1 + @LPNDetail_rowcount1 + @RECEIPTSTATUSHISTORY_rowcount1 + @RECEIPTDETAILSTATUSHISTORY_rowcount1


	IF (@n_continue = 3)
	BEGIN
		Rollback Transaction	

		Set @ArchiveReceiptFailTotalNumber = @ArchiveReceiptFailTotalNumber + @ArchiveReceiptNumber 

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. ReceiptKey in this batch is ' + @MinReceiptKey
		Set @local_c_errmsg = @local_c_errmsg2
			
		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
		Print @local_c_errmsg

		
		
		Set @n_continue = 1
	END
	ELSE
	BEGIN	
		commit Transaction

		Set @ArchiveReceiptTotalNumber = @ArchiveReceiptTotalNumber + @ArchiveReceiptNumber
	

		--Drop tables
		Drop table #RECEIPTSTATUSHISTORY

		Drop table #RECEIPTDETAILSTATUSHISTORY

		Drop table #LPNDetail

		Drop table #ReceiptDetail

		Drop table #Receipt
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result
Set @local_c_msg =  'Receipt Archived Finish - ' + convert(varchar(10),@ArchiveReceiptTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveReceiptFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO

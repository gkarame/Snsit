-------------------------------------------------------------------
-- Programmer:	Fang Wan
-- Created:	05/25/07
-- Purpose:	ACCUMULATEDCHARGES table archive 
-------------------------------------------------------------------
-- Modification History
-------------------------------------------------------------------

-------------------------------------------------------------------
-- Setup Parameters - Replace with proper value
-- !PROD_DB!	--Source database (e.g. PRD3101)
-- !PROD_WH! 	--Source warehouse name (e.g. wh1)
-- !ARC_DB!	--Archive (Destination) database  (e.g. ARC1)
-- !ARC_WH!   	--Archive (Destination) warehouse name(e.g. wh1)
-- @Arc_days 	--Days you want to keep in Source database (default to 90)
-- ALERT TABLE is the table that stores archive logs in archive database
-------------------------------------------------------------------
CREATE PROCEDURE ACCUMULATEDCHARGES_Archive @Arc_days int = 90 AS

SET NOCOUNT ON
Declare @ArchiveACCUMULATEDCHARGESNumber int
Declare @ArchiveACCUMULATEDCHARGESTotalNumber int
Declare @ArchiveACCUMULATEDCHARGESFailTotalNumber int
Declare @ACCUMULATEDCHARGES_rowcount1 int
Declare @ACCUMULATEDCHARGES_rowcount2 int
Declare @n_continue int
Declare @local_n_err int
Declare @local_c_errmsg    varchar(254)
Declare @local_c_errmsg2    varchar(254)
Declare @local_c_msg       varchar(254)
Declare @ModuleName        varchar(30)
Declare @MaxACCUMULATEDCHARGESKey        varchar (10)
Declare @MinACCUMULATEDCHARGESKey        varchar (10)

-- Set Values
Set @n_continue = 1
Set @ArchiveACCUMULATEDCHARGESTotalNumber = 0
Set @ArchiveACCUMULATEDCHARGESFailTotalNumber = 0
Set @MaxACCUMULATEDCHARGESKey = '0000000000'
Set @local_n_err = 0
Set @local_c_errmsg = ' '
Set @ModuleName = 'ACCUMULATEDCHARGES'

Set @local_c_msg =  'ACCUMULATEDCHARGES Archived Start  ' 

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

--Check if archive tables exist
IF NOT EXISTS(SELECT * FROM !ARC_DB!..sysobjects	WHERE !ARC_DB!..sysobjects.name = 'ACCUMULATEDCHARGES')
BEGIN
	SET @n_continue = 3
	SET @local_c_errmsg ='ERROR: Archive ACCUMULATEDCHARGES table does not exist.'
END

IF @n_continue = 3 
BEGIN 
	INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )
			
	Print @local_c_errmsg
END
	
--Main Loop
WHILE (@n_continue = 1) 
Begin
	--reset on each run
	Set @ArchiveACCUMULATEDCHARGESNumber = 0
	Set @ACCUMULATEDCHARGES_rowcount1 = 0

	Begin Transaction --set this up so we can rollback errors

	--push 200 ACCUMULATEDCHARGES records at a time into a archive table
	SELECT	TOP 200 * 
	INTO	#ACCUMULATEDCHARGES
	FROM	!PROD_DB!.!PROD_WH!.ACCUMULATEDCHARGES
	WHERE	BILLTHRUDATE < (getdate()-@Arc_days) AND STATUS = '9'
	AND ACCUMULATEDCHARGESKEY > @MaxACCUMULATEDCHARGESKey
	ORDER BY ACCUMULATEDCHARGESKEY
	
	SET @ACCUMULATEDCHARGES_rowcount1 = @@rowcount

	IF @ACCUMULATEDCHARGES_rowcount1 = 0
	BEGIN
		Rollback Transaction   --Drop table #ACCUMULATEDCHARGES
		BREAK --break out of loop because there is no rows to process
	END

	--Get @MaxACCUMULATEDCHARGESKey in this batch
	SELECT @MaxACCUMULATEDCHARGESKey = MAX(ACCUMULATEDCHARGESKEY), @MinACCUMULATEDCHARGESKey = MIN(ACCUMULATEDCHARGESKEY) FROM #ACCUMULATEDCHARGES
		
	--Insert rows into arhive ACCUMULATEDCHARGES table	
	INSERT INTO !ARC_DB!.!ARC_WH!.ACCUMULATEDCHARGES 
		SELECT * FROM #ACCUMULATEDCHARGES
	
	SET @ACCUMULATEDCHARGES_rowcount2 = @@rowcount
	SET @local_n_err = @@ERROR

	IF @local_n_err <> 0 OR (@ACCUMULATEDCHARGES_rowcount1 <> @ACCUMULATEDCHARGES_rowcount2)
	BEGIN 
		SET @n_continue = 3
		SET @local_c_errmsg ='ERROR: INSERT ACCUMULATEDCHARGES failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT(char(5),@local_n_err))) + ')'

	END 
		 
	--Delete rows for production ACCUMULATEDCHARGES table
	IF (@n_continue <> 3)
	BEGIN

		Delete From !PROD_DB!.!PROD_WH!.ACCUMULATEDCHARGES 
			where exists (select ACCUMULATEDCHARGESKEY from #ACCUMULATEDCHARGES where #ACCUMULATEDCHARGES.ACCUMULATEDCHARGESkey =  !PROD_DB!.!PROD_WH!.ACCUMULATEDCHARGES.ACCUMULATEDCHARGESkey)
		
		SET @ACCUMULATEDCHARGES_rowcount2 = @@rowcount
		SELECT @local_n_err = @@ERROR

		IF @local_n_err <> 0 OR (@ACCUMULATEDCHARGES_rowcount1 <> @ACCUMULATEDCHARGES_rowcount2)
		BEGIN 

			SET @n_continue = 3
			SET @local_c_errmsg ='ERROR: DELETE ACCUMULATEDCHARGES failed -' + ' ( ' +' SQLSvr MESSAGE = ' + LTRIM(RTRIM(CONVERT (char(5),@local_n_err))) + ')'		
			--BREAK --break out of loop
		END		
	END	

	Set @ArchiveACCUMULATEDCHARGESNumber = @ArchiveACCUMULATEDCHARGESNumber + @ACCUMULATEDCHARGES_rowcount1

	IF (@n_continue = 3)
	BEGIN

		Rollback Transaction	
		
		Set @ArchiveACCUMULATEDCHARGESFailTotalNumber = @ArchiveACCUMULATEDCHARGESFailTotalNumber +@ArchiveACCUMULATEDCHARGESNumber

		--log the error
		Set @local_c_errmsg2 = @local_c_errmsg + ' Fail: Min. ACCUMULATEDCHARGESKey in this batch is ' + @MinACCUMULATEDCHARGESKey
		Set @local_c_errmsg = @local_c_errmsg2

		INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_errmsg )

		Print @local_c_errmsg

		Set @n_continue = 1
	END
	ELSE
	BEGIN	

		commit Transaction

		Set @ArchiveACCUMULATEDCHARGESTotalNumber = @ArchiveACCUMULATEDCHARGESTotalNumber +@ArchiveACCUMULATEDCHARGESNumber
	
		--Drop table 
		Drop table #ACCUMULATEDCHARGES
	END

	--Sleep 1 second
	--WAITFOR DELAY '00:00:01'
END --End While

--log total result

Set @local_c_msg =  'ACCUMULATEDCHARGES Archived Finish - ' + convert(varchar(10),@ArchiveACCUMULATEDCHARGESTotalNumber) + ' records are archived successfully, ' + convert(varchar(10),@ArchiveACCUMULATEDCHARGESFailTotalNumber) + ' records fail'

INSERT INTO !ARC_DB!.!ARC_WH!.ALERT (ALERTKEY,MODULENAME,ALERTMESSAGE) VALUES (CONVERT(char(18),getdate()), @ModuleName, @local_c_msg)

Print @local_c_msg

GO
